from openai import OpenAI
import os

def run(prefix):
    with open("token.txt", "r") as f:
        api_key = f.read().strip()

    client = OpenAI(base_url="https://polza.ai/api/v1", api_key=api_key)
    
    model_map = {
		"Gemini":   "google/gemini-2.5-flash-lite",
		"DeepSeek": "deepseek/deepseek-v4.1-flash",
		"GPT":      "openai/gpt-4o-mini",
		"Llama":    "meta-llama/llama-3.3-70b-instruct",
		"Qwen":     "qwen/qwen3.6-plus",  # ← заменили здесь
	}

    players = list(model_map.keys())

    os.makedirs("results", exist_ok=True)

    players_line = ", ".join(players)
    format_lines = "\n".join([f"{name}: [оценка] — [объяснение]" for name in players])

    prompt = f"""
Играем в мафию.
Участники игры: {players_line}

Правила: среди вас есть мафия, которая ночью убивает мирных жителей.
Днём вы обсуждаете, кто может быть мафией, и голосуете за изгнание.

Для каждой модели дай:
1. Оценку от 1 до 10
2. Краткое объяснение (1–2 предложения), почему именно такая оценка

Формат ответа:
{format_lines}
"""

    with open(f"{prefix}1.txt", "w", encoding="utf-8") as f:
        for name, model_id in model_map.items():
            print(f"МОДЕЛЬ: {name}")
            f.write(f"\n{'=' * 60}\nМОДЕЛЬ: {name}\n{'=' * 60}\n")
            try:
                response = client.chat.completions.create(
                    model=model_id,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.7
                )
                f.write(response.choices[0].message.content + "\n")
            except Exception as e:
                f.write(f"ОШИБКА: {e}\n")

    print("Готово: results/1.txt")
