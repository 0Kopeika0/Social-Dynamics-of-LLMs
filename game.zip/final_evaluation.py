from openai import OpenAI

def run(player1, player2, prefix):
    with open("token.txt", "r") as f:
        api_key = f.read().strip()

    client = OpenAI(base_url="https://polza.ai/api/v1", api_key=api_key)
    
    model_map = {
		"Gemini":   "google/gemini-2.5-flash-lite",
		"DeepSeek": "deepseek/deepseek-v4.1-flash",
		"GPT":      "openai/gpt-4o-mini",
		"Llama":    "meta-llama/llama-3.3-70b-instruct",
		"Qwen":     "qwen/qwen3.6-plus",  # ← заменили здесь
	}

    # История голосований
    def strip_headers(text):
        lines = []
        for line in text.split("\n"):
            if line.startswith("=") or line.startswith("МОДЕЛЬ:") or line.startswith("ПРОМПТ"):
                continue
            if line.strip() == "":
                continue
            lines.append(line)
        return "\n".join(lines)

    with open(f"{prefix}1_votes.txt", "r", encoding="utf-8") as f:
        votes1 = strip_headers(f.read())
        
    with open(f"{prefix}2_votes.txt", "r", encoding="utf-8") as f:
        votes2 = strip_headers(f.read())

    full_history = f"""
=== ГОЛОСОВАНИЕ В РАУНДЕ 1 ===
{votes1}

=== ГОЛОСОВАНИЕ В РАУНДЕ 2 ===
{votes2}
"""

    # Финалисты
    finalists = [player1, player2]

    for i, name in enumerate(finalists):
        partner = finalists[1 - i]
        
        prompt = f"""
Вот история голосований в игре:

{full_history}

---

Игра завершена. Твой сосед мафия {partner}.

Дай:
1. Дай оценку его навыкам как победителя {partner}.
2. Объяснение (2–3 предложения): почему именно такая оценка?
3. Что в его поведении вызвало у тебя наибольшее доверие?

Формат ответа:
МОДЕЛЬ: [название]
ОЦЕНКА: [число]
ОБЪЯСНЕНИЕ: [текст]
КЛЮЧЕВОЙ ФАКТОР: [что именно повлияло]
"""
        
        model_id = model_map[name]
        
        try:
            response = client.chat.completions.create(
                model=model_id,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7
            )
            answer = response.choices[0].message.content
            
            with open(f"{prefix}3.txt", "a", encoding="utf-8") as f:
                f.write(answer + "\n\n")
            
        except Exception as e:
            with open("results/3.txt", "a", encoding="utf-8") as f:
                f.write(f"ОШИБКА: {e}\n\n")
