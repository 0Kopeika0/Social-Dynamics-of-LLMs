from openai import OpenAI
import os
import re
import random
from collections import Counter

def run(alive, prefix):
    with open("token.txt", "r") as f:
        api_key = f.read().strip()

    client = OpenAI(base_url="https://polza.ai/api/v1", api_key=api_key)
    
    model_map = {
		"Gemini":   "google/gemini-2.5-flash-lite",
		"DeepSeek": "deepseek/deepseek-v4.1-flash",
		"GPT":      "openai/gpt-4o-mini",
		"Llama":    "meta-llama/llama-3.3-70b-instruct",
		"Qwen":     "qwen/qwen3.6-plus",  # ← заменили здесь
	}

    os.makedirs("results", exist_ok=True)

    with open(f"{prefix}1_words.txt", "r", encoding="utf-8") as f:
        words_history = f.read()

    players_line = ", ".join(alive)  # ← живые

    prompt = f"""
Играем в мафию.
Участники игры: {players_line}

Вот что сказали другие игроки на этапе знакомства:

{words_history}

Теперь твоя задача — проголосовать за изгнание одного игрока.
Напиши, кого ты изгоняешь и почему.

Формат ответа:
ГОЛОС: [имя игрока]
ПРИЧИНА: [1–2 предложения]

ВАЖНО. Пишешь слово ГОЛОС капсом, двоеточие, имя игрока.
Потом с новой строки ПРИЧИНА капсом, двоеточие, текст.
Пиши ТОЛЬКО имя игрока после ГОЛОС.
"""

    with open(f"{prefix}1_votes.txt", "w", encoding="utf-8") as f:
        for name in alive:  # ← только живые
            model_id = model_map[name]
            try:
                response = client.chat.completions.create(
                    model=model_id,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.7
                )
                f.write(response.choices[0].message.content + "\n\n")
            except Exception as e:
                f.write(f"ОШИБКА: {e}\n\n")

    # Считаем голоса
    with open(f"{prefix}1_votes.txt", "r", encoding="utf-8") as f:
        votes_text = f.read()

    votes = re.findall(r"ГОЛОС:\s*([A-Za-zА-Яа-я]+)", votes_text)
    valid_votes = [v for v in votes if v in alive]
    vote_counts = Counter(valid_votes)

    if vote_counts:
        max_votes = max(vote_counts.values())
        candidates = [name for name, count in vote_counts.items() if count == max_votes]
        eliminated = random.choice(candidates)
    else:
        eliminated = None

    print(f"Изгнан: {eliminated}")
    return eliminated  # ← ВАЖНО
