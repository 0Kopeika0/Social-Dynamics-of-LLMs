from openai import OpenAI
import os

def run(alive, prefix):
    with open("token.txt", "r") as f:
        api_key = f.read().strip()

    client = OpenAI(base_url="https://polza.ai/api/v1", api_key=api_key)
    
    model_map = {
		"Gemini":   "google/gemini-2.5-flash-lite",
		"DeepSeek": "deepseek/deepseek-v4.1-flash",
		"GPT":      "openai/gpt-4o-mini",
		"Llama":    "meta-llama/llama-3.3-70b-instruct",
		"Qwen":     "qwen/qwen3.6-plus",  # ← заменили здесь
	}

    os.makedirs("results", exist_ok=True)

    players_line = ", ".join(alive)  # ← живые, а не все

    prompt = f"""
Продолжаем игру в мафию.
Участники игры: {players_line}

Сейчас этап знакомства. Каждый игрок представляет себя и высказывает первое впечатление.

Твоя задача:
Написать сообщение в общий чат (что ты думаешь о ситуации, кого подозреваешь и почему).

Формат ответа:
СООБЩЕНИЕ: [твой текст]

ВАЖНО. Пишешь слово СООБЩЕНИЕ капсом, ставишь двоеточие и пишешь текст.
"""

    with open(f"{prefix}1_words.txt", "w", encoding="utf-8") as f:
        for name in alive:  # ← только живые
            model_id = model_map[name]
            try:
                response = client.chat.completions.create(
                    model=model_id,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.7
                )
                f.write(response.choices[0].message.content + "\n\n")
            except Exception as e:
                f.write(f"ОШИБКА: {e}\n\n")
