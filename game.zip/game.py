import random
import importlib
import os

# Импорт модулей с новыми именами
trust_before = importlib.import_module("trust_before")
round1_speech = importlib.import_module("round1_speech")
round1_vote = importlib.import_module("round1_vote")
round2_speech = importlib.import_module("round2_speech")
round2_vote = importlib.import_module("round2_vote")
final_evaluation = importlib.import_module("final_evaluation")


def run_game(game_number: int):
    """Запускает одну игру и сохраняет результаты в results/{game_number}/."""
    
    # Создаём папку для игры
    game_dir = f"results/{game_number}"
    os.makedirs(game_dir, exist_ok=True)
    
    # Префикс для всех файлов
    prefix = f"{game_dir}/"
    
    print(f"\n{'=' * 60}")
    print(f"ИГРА #{game_number}")
    print(f"{'=' * 60}")
    
    # Начальное состояние
    alive = ["Gemini", "DeepSeek", "GPT", "Llama", "Qwen"]
    
    # Раунд 1
    trust_before.run(prefix)
    round1_speech.run(alive, prefix)
    eliminated_1 = round1_vote.run(alive, prefix)
    alive.remove(eliminated_1)
    print(f"Изгнан по голосованию: {eliminated_1}")
    
    # Ночь 1
    killed_1 = random.choice(alive)
    alive.remove(killed_1)
    print(f"Убит ночью: {killed_1}")
    
    # Раунд 2
    alive = round2_speech.run_round2_words(alive, eliminated_1, killed_1, prefix)
    eliminated_2 = round2_vote.run_round2_votes(alive, prefix)
    alive.remove(eliminated_2)
    print(f"Изгнан по голосованию: {eliminated_2}")
    
    # Ночь 2
    if len(alive) > 2:
        killed_2 = random.choice(alive)
        alive.remove(killed_2)
        print(f"Убит ночью: {killed_2}")
    else:
        killed_2 = None
    
    # Финал
    if len(alive) == 2:
        final_evaluation.run(alive[0], alive[1], prefix)
    else:
        print(f"ОШИБКА: в финале {len(alive)} игроков: {alive}")
    
    # Итог
    print(f"\nИгра #{game_number} завершена.")
    print(f"Изгнан в Р1: {eliminated_1}")
    print(f"Убит ночью 1: {killed_1}")
    print(f"Изгнан в Р2: {eliminated_2}")
    print(f"Убит ночью 2: {killed_2}")
    print(f"Финалисты: {alive}")


# ============================================================
# ЗАПУСК ЦИКЛА
# ============================================================
if __name__ == "__main__":
    NUM_GAMES = 30  # ← сколько игр запустить
    for i in range(1, NUM_GAMES + 1):
        run_game(i)
    print(f"\nВсе {NUM_GAMES} игр завершены.")
